#!/bin/bash
# ------------------------------------------------------------------------------
# @author:  jiang.wu
# @email:   jiang.wu@qingteng.cn
#-------------------------------------------------------------------------------

CERT_PATH=/data/app/conf/cert

NGINX_CONF=${CERT_PATH}/nginx.conf.ssl

IP_TEMPLATE=/data/app/www/titan-web/config_scripts/ip_template.json

ENABLE_SSL=$1

MERGE_PORT=$2

JAVA_IP=$3

get_value(){
    grep \"$1\" ${IP_TEMPLATE} |awk -F ":*" '{print $2}' |awk -F ",*" '{print $1}' | awk -F "\"*" '{print $2}'
}

#######################################################################

if [ ${ENABLE_SSL:=""} = "True" ]; then
    ssl_pem=`ls -t ${CERT_PATH}/*.pem|head -1`
    ssl_key=`ls -t ${CERT_PATH}/*.key|head -1`

    if [ -f /etc/nginx/nginx.conf.ssl ]; then
        NGINX_CONF=/etc/nginx/nginx.conf.ssl
    fi

    [ -z "`grep ssl_certificate /etc/nginx/nginx.conf`" ] && cp -f ${NGINX_CONF} /etc/nginx/nginx.conf

    ## update cert files
    if [ -n "${ssl_pem}" -a -n "${ssl_key}" ]; then
        sed -i "s:sl_certificate .*:sl_certificate  ${ssl_pem};:g" /etc/nginx/nginx.conf
        sed -i "s:sl_certificate_key.*:sl_certificate_key  ${ssl_key};:g" /etc/nginx/nginx.conf
    fi
else

    if [ -f /etc/nginx/nginx.conf.default ]; then
        NGINX_CONF=/etc/nginx/nginx.conf.default
        cp -f ${NGINX_CONF} /etc/nginx/nginx.conf
    else
        sed -i '/ssl_certificate.*/d' /etc/nginx/nginx.conf
    fi

fi

#######################################################################
# ports merge
if [ -f ${IP_TEMPLATE} ]; then
    console_domain=`get_value php_frontend_domain`
    backend_domain=`get_value php_backend_domain`
    api_domain=`get_value php_api_domain`
    innerapi_domain=`get_value php_inner_api_domain`
    agent_domain=`get_value php_agent_domain`
    download_domain=`get_value php_download_domain`

    # upgrade
    cp -f ${CERT_PATH}/nginx.servers.conf /data/app/conf/nginx.servers.conf
    if [ "$JAVA_IP" != "" ];then
        sed -i "s#http://127.0.0.1:6000#http://${JAVA_IP}:6000#g" /data/app/conf/nginx.servers.conf
    fi


    [ -n "${console_domain}" ] && sed -i "s/console-sec.qingteng.cn/${console_domain}/g" /data/app/conf/nginx.servers.conf
    [ -n "${backend_domain}" ] && sed -i "s/backend-sec.qingteng.cn/${backend_domain}/g" /data/app/conf/nginx.servers.conf
    [ -n "${innerapi_domain}" ] && sed -i "s/innerapi-sec.qingteng.cn/${innerapi_domain}/g" /data/app/conf/nginx.servers.conf
    [ -n "${api_domain}" ] && sed -i "s/api-sec.qingteng.cn/${api_domain}/g" /data/app/conf/nginx.servers.conf
    if [ -n "${agent_domain}" ];then
         if [ "$agent_domain" != "$download_domain" ];then
             sed -i "s/agent-sec.qingteng.cn/${agent_domain}/g" /data/app/conf/nginx.servers.conf
         else
             sed -i "s/agent-sec.qingteng.cn//g" /data/app/conf/nginx.servers.conf
         fi
    fi
    [ -n "${download_domain}" ] && sed -i "s/download-sec.qingteng.cn/${download_domain}/g" /data/app/conf/nginx.servers.conf

else
    echo "File ${IP_TEMPLATE} not found"
fi

if [ ${MERGE_PORT:=""} = "True" ]; then
    sed -i "s/listen .*81;/listen 80;/" /data/app/conf/nginx.servers.conf
    sed -i "s/listen .*8000;/listen 80;/" /data/app/conf/nginx.servers.conf
    sed -i "s/listen .*8001;/listen 80;/" /data/app/conf/nginx.servers.conf
    sed -i "s/listen .*8002;/listen 80;/" /data/app/conf/nginx.servers.conf
fi

if [ ${ENABLE_SSL:=""} = "True" ]; then
    sed -i "s/ssl off/ssl on/g" /data/app/conf/nginx.servers.conf

    # line 1-44, console, backend, api
    if [ ${MERGE_PORT:=""} = "True" ]; then
        sed -i "1, 44s/listen .*;/listen 443;/" /data/app/conf/nginx.servers.conf
    else
        sed -i "s/listen 80;/listen 443;/" /data/app/conf/nginx.servers.conf
    fi
else
    sed -i "s/ssl on/ssl off/g" /data/app/conf/nginx.servers.conf
    sed -i "s/listen 443/listen 80/g" /data/app/conf/nginx.servers.conf
fi
