#!/bin/bash
# ------------------------------------------------------------------------------
# @author:  jiang.wu
# @email:   jiang.wu@qingteng.cn
#-------------------------------------------------------------------------------

FILE_ROOT=`cd \`dirname $0\` && pwd`

source ${FILE_ROOT}/utils.sh

IS_UPGRADE=false

REMOTE_QT_PACKAGE_DIR=/data/qt_rpms

PHP_EXEC=/usr/local/php/bin/php
WEB_PATH=/data/app/www/titan-web
SERVER_EXEC=/data/app/titan-servers/bin/titan-server

[ ! -f ${FILE_ROOT}/ip_template.json ] && error_log " Cannot found ${FILE_ROOT}/ip_template.json"

IP_TEMPLATE=${FILE_ROOT}/ip_template.json
REMOTE_DIR_IP_TEMPLATE=/data/app/www/titan-web/config_scripts

PACKAGE_TITAN_SERVER=(erl_om_1 erl_om_2 erl_dh_1 erl_dh_2 erl_sh_1_private erl_sh_2_private)
PACKAGE_TITAN_WEB=(php_frontend_private
                   php_backend_private
                   php_agent_private
                   php_download_private
                   php_api_private
                   php_inner_api)

LOCAL_CERT_PATH=${FILE_ROOT}/cert
REMOTE_CERT_PATH=/data/app/conf/cert

## --------------------------------------- Utils --------------------------------- ##

help() {
    echo "--------------------------------------------------------------------------"
    echo "                             Usage information                            "
    echo "--------------------------------------------------------------------------"
    echo ""
    echo "./titan-app.sh [Options]                                                  "
    echo "                                                                          "
    echo "Options:                                                                  "
    echo "  install (v3|v2)               installation and initialization           "
    echo "  upgrade (v3|v2)               upgrade application                       "
    echo "  upgrade_v2_to_v3              cross-version upgrade                     "
    echo "  distribute (v3|v2)            distribute rpm, then install              "
    echo "  config                        build config files                        "
    echo "  init_db                       create mysql database                     "
    echo "  launch (v3|v2)                start application                         "
    echo "  init_data                     sync rules & agent & bash                 "
    echo "  register (v3|v2)              register default account                  "
    echo "  update_rules                  sync rules                                "
    echo "  update_agent_url              update agent & bash url                   "
    echo "  restart_php                   restart php server                        "
    echo "  start_erlang                  restart all erlang services               "
    echo "  stop_erlang                   stop all erlang services                  "
    echo "  start_server                  restart titan-server                      "
    echo "  stop_server                   stop titan-server                         "
    echo "  start_java                    start java server                         "
    echo "  stop_java                     stop java server                          "
    echo "  dump                          backup mysql database                     "
    echo "  db_merge                      merge db while upgrade from v2 to v3      "
    echo "  jdb_flush                     flush java mongodb                        "
    echo "  cleancache                    clean cache for java                      "
    echo "  switchcompany mainID subID    switch company when upgrade from v2 to v3 "
    echo "  update_rules                  upgrade rules                             "
    echo "  update_license                update license info                       "
    echo "  change_wisteria_memory        change java memory                        "
    echo "  backup_config                 backup all config file                    "
    echo "  java_v310_update              update java                               "
    echo "                                                                          "
    echo "  Example:                                                                "
    echo "    ./titan-app.sh install v3                                             "
    echo "    ./titan-app.sh upgrade v3                                             "
    echo "    ./titan-app.sh upgrade_v2_to_v3                                       "
    echo "--------------------------------------------------------------------------"
    exit 1
}

setup_np_ssh_erlang(){
    local np_done=""
    for node in ${PACKAGE_TITAN_SERVER[*]};
    do
        local ip=`get_ip ${node}`
        if [ -z `echo ${np_done} |grep ${ip}` ]; then
            set_np_authorized ${ip}
            np_done="${np_done}**${ip}"
        fi
    done
}

## --------------- Backup ----------------##
backup_config(){
    role_mongo=(db_mongo_erlang db_mongo_java)
    role_redis=(db_redis_erlang db_redis_java db_redis_php)
    role_mysql=(db_mysql_erlang db_mysql_php)
    role_java=(java java_kafka java_zookeeper)
    role_erlang=(erl_channel_private erl_dh_1 erl_dh_2 erl_om_1 erl_om_2 erl_selector_private erl_sh_1_private erl_sh_2_private)
    role_php=(php_frontend_private php_api_private)

    bak_dir=`date +%Y%m%d-%H%M%S`
    for role in ${role_mongo[*]} ${role_redis[*]} ${role_mysql[*]} ${role_java[*]} ${role_erlang[*]} ${role_php[*]};do
        ip=`get_ip $role`
        if [ "$ip" != "" ];then
            [ -f "/tmp/$bak_dir/$ip/$role" ] || mkdir -p /tmp/$bak_dir/$ip/$role
            case $role in
                db_mongo_erlang|db_mongo_java)
                    remote_scp $ip /usr/local/qingteng/mongodb/conf/mongod.conf /tmp/$bak_dir/$ip/$role
                ;;
                db_redis_erlang)
                    remote_scp $ip /etc/redis/6379.conf /tmp/$bak_dir/$ip/$role
                ;;
                db_redis_php)
                    remote_scp $ip /etc/redis/6380.conf /tmp/$bak_dir/$ip/$role
                ;;
                db_redis_java)
                    remote_scp $ip /etc/redis/6381.conf /tmp/$bak_dir/$ip/$role
                ;;
                db_mysql_erlang|db_mysql_php)
                    remote_scp $ip /etc/my.cnf /tmp/$bak_dir/$ip/$role
                ;;
                java)
                    remote_scp $ip /data/app/titan-wisteria/config/java.json /tmp/$bak_dir/$ip/$role
                    remote_scp $ip /data/app/titan-patrol-srv/patrol-srv.conf /tmp/$bak_dir/$ip/$role
                    remote_scp $ip /data/app/titan-user-srv/user-srv.conf /tmp/$bak_dir/$ip/$role
                    remote_scp $ip /data/app/titan-gateway/gateway.conf /tmp/$bak_dir/$ip/$role
                ;;
                java_kafka)
                    remote_scp $ip /usr/local/qingteng/kafka/config/server.properties  /tmp/$bak_dir/$ip/$role
                    remote_scp $ip /usr/local/qingteng/kafka/config/kafka.env  /tmp/$bak_dir/$ip/$role
                ;;
                java_zookeeper)
                    remote_scp $ip /usr/local/qingteng/zookeeper/conf/zoo.cfg  /tmp/$bak_dir/$ip/$role
                    remote_scp $ip /usr/local/qingteng/zookeeper/conf/java.env  /tmp/$bak_dir/$ip/$role
                ;;
                erl_channel_private)
                    remote_scp $ip /data/app/titan-channel/etc/common.json /tmp/$bak_dir/$ip/$role
                    remote_scp $ip /data/app/titan-channel/etc/hosts /tmp/$bak_dir/$ip/$role
                ;;
                erl_selector_private)
                    remote_scp $ip /data/app/titan-selector/etc/common.json /tmp/$bak_dir/$ip/$role
                    remote_scp $ip /data/app/titan-selector/etc/hosts /tmp/$bak_dir/$ip/$role
                ;;
                erl_dh_1|erl_dh_2|erl_om_1|erl_om_2|erl_sh_1_private|erl_sh_2_private)
                    remote_scp $ip /data/app/titan-servers/etc/common.json  /tmp/$bak_dir/$ip/$role
                    remote_scp $ip /data/app/titan-servers/etc/hosts  /tmp/$bak_dir/$ip/$role
                ;;
                php_frontend_private|php_api_private)
                    remote_scp $ip '/data/app/conf/*' /tmp/$bak_dir/$ip/$role
                    remote_scp $ip /data/app/www/titan-web/conf/build.json /tmp/$bak_dir/$ip/$role
                    remote_scp $ip /data/app/www/titan-web/conf/product/application.ini /tmp/$bak_dir/$ip/$role
                    remote_scp $ip /data/app/www/titan-web/config_scripts/ip.json /tmp/$bak_dir/$ip/$role
                    remote_scp $ip /data/app/www/titan-web/config_scripts/ip_template.json /tmp/$bak_dir/$ip/$role
                ;;
                *)
                ;;
            esac
        fi
    done
}

java_v310_update(){
    java_host=`get_ip java`
    if [ "$1" != "" ];then
    ssh_t ${java_host}  "\
    cd /data/app/upgradeTool && \
    /usr/local/qingteng/python2.7/bin/python upgrade.py  --type standalone byVersion --fromVer $1 --toVer 3.1.0"
    check "java v$1 update v3.1.0"
    else
    ssh_t ${java_host}  "\
    cd /data/app/upgradeTool && \
    /usr/local/qingteng/python2.7/bin/python upgrade.py  --type standalone byVersion --fromVer 3.0.6 --toVer 3.1.0"
    check "java v306 update v3.1.0"
    fi
}



## --------------- Distribution & Installation ------------------- ##

distribute_titan_server(){

    local package_sent=""
    for node in ${PACKAGE_TITAN_SERVER[*]};
    do
        local ip=`get_ip ${node}`

        [ -z "${ip}" ] && error_log "${node}'s ip is empty"

        if [ -z "`echo ${package_sent} |grep ${ip}`" ]; then
            # distribute
            local rpm_lic=`ls -t ${FILE_ROOT}/*/titan-license-*.rpm |head -1`
            local rpm_server=`echo ${FILE_ROOT}/*/titan-servers-*.rpm`

            if [ -n "${rpm_lic}" -a "true" = ${IS_UPGRADE} ]; then
                execute_rsync ${ip} ${rpm_lic} ${REMOTE_QT_PACKAGE_DIR}
            fi
            [ "false" = ${IS_UPGRADE} ] && execute_rsync ${ip} ${rpm_lic} ${REMOTE_QT_PACKAGE_DIR}
            execute_rsync ${ip} ${rpm_server} ${REMOTE_QT_PACKAGE_DIR}
            # install
            install_rpm ${ip} ${rpm_lic##*/}
            install_rpm ${ip} ${rpm_server##*/}
            package_sent="${package_sent}@${ip}"
        fi
    done
}

distribute_titan_web(){

    local package_sent=""
    for node in ${PACKAGE_TITAN_WEB[*]};
    do
        local ip=`get_ip ${node}`

        [ -z "${ip}" ] && error_log "${node}'s ip is empty"

        if [ -z "`echo ${package_sent} |grep ${ip}`" ]; then
            local rpm_web=`echo ${FILE_ROOT}/*/titan-web-*.rpm`
            local rpm_agent=`echo ${FILE_ROOT}/*/titan-agent-*.rpm`
            # distribute
            execute_rsync ${ip} ${rpm_web} ${REMOTE_QT_PACKAGE_DIR}
            execute_rsync ${ip} ${rpm_agent} ${REMOTE_QT_PACKAGE_DIR}
            # install

            # get the value of product_name,
            # keep it, then restore after upgrade
            local customer=`get_ip product_name`
            install_rpm ${ip} ${rpm_web##*/}
            install_rpm ${ip} ${rpm_agent##*/}
            # restore
            [ -n "${customer}" ] && ssh_t ${ip} "\
            sed -i \"s/\"product_name\":.*/\"product_name\": \"${customer}\",/\" /data/app/www/titan-web/conf/build.json"

            package_sent="${package_sent}@${ip}"
        fi
    done
}

distribute_titan_channel(){

    local ch_ip=`get_ip erl_channel_private`

    [ -z "${ch_ip}" ] && error_log "erl_channel_private's ip is empty"

    local rpm_lic=`ls -t ${FILE_ROOT}/*/titan-license-*.rpm |head -1`
    local rpm_ch=`echo ${FILE_ROOT}/*/titan-channel-*.rpm`
    # distribute

    if [ -n "${rpm_lic}" -a "true" = ${IS_UPGRADE} ]; then
        execute_rsync ${ch_ip} ${rpm_lic} ${REMOTE_QT_PACKAGE_DIR}
    fi
    [ "false" = ${IS_UPGRADE} ] && execute_rsync ${ch_ip} ${rpm_lic} ${REMOTE_QT_PACKAGE_DIR}

    execute_rsync ${ch_ip} ${rpm_ch} ${REMOTE_QT_PACKAGE_DIR}
    # install
    install_rpm ${ch_ip} ${rpm_lic##*/}
    install_rpm ${ch_ip} ${rpm_ch##*/}

}

distribute_titan_selector(){

    local sl_ip=`get_ip erl_selector_private`

    [ -z "${sl_ip}" ] && error_log "erl_selector_private's ip is empty"

    local rpm_lic=`ls -t ${FILE_ROOT}/*/titan-license-*.rpm |head -1`
    local rpm_sl=`echo ${FILE_ROOT}/*/titan-selector-*.rpm`

    if [ -n "${rpm_lic}" -a "true" = ${IS_UPGRADE} ]; then
        execute_rsync ${sl_ip} ${rpm_lic} ${REMOTE_QT_PACKAGE_DIR}
    fi
    [ "false" = ${IS_UPGRADE} ] && execute_rsync ${sl_ip} ${rpm_lic} ${REMOTE_QT_PACKAGE_DIR}

    execute_rsync ${sl_ip} ${rpm_sl} ${REMOTE_QT_PACKAGE_DIR}
    install_rpm ${sl_ip} ${rpm_lic##*/}
    install_rpm ${sl_ip} ${rpm_sl##*/}

}

distribute_titan_rabbitmq(){
    local mq_ip=`get_ip erl_rabbitmq`

    [ -z "${mq_ip}" ] && error_log "erl_rabbitmq's ip is empty"

    local rpm_mq=`echo ${FILE_ROOT}/*/titan-rabbitmq-*.rpm`
    execute_rsync ${mq_ip} ${rpm_mq} ${REMOTE_QT_PACKAGE_DIR}
    install_rpm ${mq_ip} ${rpm_mq##*/}
}

distribute_titan_wisteria(){
    local java_ip=`get_ip java`
    local php_ip=`get_ip php_inner_api`

    [ -z "${java_ip}" ] && error_log "java's ip is empty"

    execute_rsync ${java_ip}  ${FILE_ROOT}/setup_np_ssh.sh /tmp
    ssh_t ${java_ip} "bash /tmp/setup_np_ssh.sh ${DEFAULT_USER}@${php_ip} ${DEFAULT_PORT}"

    local rpm_java=`echo ${FILE_ROOT}/*/titan-wisteria-*.rpm`
    execute_rsync ${java_ip} ${rpm_java} ${REMOTE_QT_PACKAGE_DIR}
    install_rpm ${java_ip} ${rpm_java##*/}
}

distribute_config(){
    local config_sent=""
    for node in ${PACKAGE_TITAN_WEB[*]};
    do
        local ip=`get_ip ${node}`

        [ -z "${ip}" ] && error_log "${node}'s ip is empty"

        if [ -z "`echo ${config_sent} |grep ${ip}`" ]; then

            # ssl certifications
            execute_rsync ${ip} ${LOCAL_CERT_PATH}/ ${REMOTE_CERT_PATH}

            # ip_template.json
            ssh_t ${ip} "cd /data/app/www/titan-web/config_scripts && \
            [ -f ip.json ] && mv ip.json ip.json_bak"
            execute_rsync ${ip}  ${IP_TEMPLATE} ${REMOTE_DIR_IP_TEMPLATE}
            config_sent="${config_sent}@${ip}"
        fi
    done
}



install_rpm(){
    local host=$1
    local rpm=$2
    ssh_t ${host} "cd $REMOTE_QT_PACKAGE_DIR && rpm -ivh --force ${rpm}"
    check "Install ${rpm} on ${host} "
}

## -------------------------- Launch ----------------------------- ##

launch_erlang_node(){
    local host=$1
    local app=$2
    local req_async=false

    local cmd=""

    if [ -z $3 ]; then
        cmd="${app} stop &> /dev/null && ${app} hp"
    else
        case $3 in
            om_node|dh_node|sh_node)
                local id=$4
                local num=$5
                if [ -z "${id}" ];then
                    cmd="${app} stop &> /dev/null && ${app} -r $3 hp"
                else
                    cmd="${app} stop &> /dev/null && ${app} -r $3 -id $4 -n $5"
                    req_async=true
                fi
                ;;
            [1-9]*)
                # $3 is number
                local num=$4
                cmd="${app} stop &> /dev/null && ${app} -id $3 -n $4"
                req_async=true
                ;;
            *)
                error_log "launch_erlang_node($*)"
                exit 1
                ;;
        esac
    fi

    if [ ${req_async} = "false" ]; then
        ssh_tt ${host} "\
        grep -q \"alias to_erl\" /root/.bashrc || \
        echo \"alias to_erl='erl_call() { TO_ERL=\\\`ls -d /root/*_root/*_server/titan_otp/otp-*/priv/pkg/bin/to_erl|head -1\\\`; \\\$TO_ERL \\\$1; }; erl_call'\" >> /root/.bashrc; \
        ${cmd} || exit 1"
    else
        ssh_tt ${host} "\
        grep -q \"alias to_erl\" /root/.bashrc || \
        echo \"alias to_erl='erl_call() { TO_ERL=\\\`ls -d /root/*_root/*_server/titan_otp/otp-*/priv/pkg/bin/to_erl|head -1\\\`; \\\$TO_ERL \\\$1; }; erl_call'\" >> /root/.bashrc; \
        ${cmd} || exit 1" &
    fi

}

start_server_role(){
    local app=$1
    local node=$2

    case ${node} in
        sh_node)
            local ip_1=`get_ip erl_sh_1_private`
            local ip_2=`get_ip erl_sh_2_private`
            ;;
        dh_node)
            local ip_1=`get_ip erl_dh_1`
            local ip_2=`get_ip erl_dh_2`
            ;;
        om_node)
            local ip_1=`get_ip erl_om_1`
            local ip_2=`get_ip erl_om_2`
            ;;
        *)
            error_log "start_server_node($*)"
            exit 1
            ;;
    esac

    if [ ${ip_1} = ${ip_2}  ]; then
        launch_erlang_node ${ip_1} ${app} ${node}
    else
        launch_erlang_node ${ip_1} ${app} ${node} 1 1
        sleep 5
        launch_erlang_node ${ip_2} ${app} ${node} 2 2
    fi
    wait
}

### TODO:
start_titan_server() {

    local ips=""
    local num=0
    for node in ${PACKAGE_TITAN_SERVER[*]};
    do
        local ip=`get_ip ${node}`
        if [ -z `echo ${ips} |grep ${ip}` ]; then
            ips="${ips}*${ip}"
            let num++
        fi
    done

    ## num=1: om dh sh installed on one machine
    if [ ${num} -eq 1 ]; then
        launch_erlang_node `echo ${ips} |awk -F "*" '{print $2}'` ${SERVER_EXEC}
    else
        start_server_role ${SERVER_EXEC} om_node
        start_server_role ${SERVER_EXEC} dh_node
        start_server_role ${SERVER_EXEC} sh_node
    fi

}

start_titan_channel(){
    local ch_ip=`get_ip erl_channel_private`
    local channel=/data/app/titan-channel/bin/channel

    launch_erlang_node ${ch_ip} ${channel}

    wait
}

start_titan_selector(){
    local sl_ip=`get_ip erl_selector_private`
    local selector=/data/app/titan-selector/bin/selector

    launch_erlang_node ${sl_ip} ${selector}
    wait
}

start_titan_rabbitmq(){
    local mq_ip=`get_ip erl_rabbitmq`
    ssh_t ${mq_ip} "\
    grep -q \"alias to_erl\" /root/.bashrc || \
    echo \"alias to_erl='erl_call() { TO_ERL=\\\`ls -d /root/*_root/*_server/titan_otp/otp-*/priv/pkg/bin/to_erl|head -1\\\`; \\\$TO_ERL \\\$1; }; erl_call'\" >> /root/.bashrc; \
    service rabbitmq-server restart || exit 1"
}

start_erlang_services(){
    info_log "================ Launching RabbitMQ =================="
    start_titan_rabbitmq
    info_log "================ Launching Channel ==================="
    start_titan_channel
    info_log "================ Launching Server ===================="
    start_titan_server
    info_log "================ Launching Selector =================="
    start_titan_selector
}

stop_erlang_node(){
    local host=$1
    local app=$2
    ssh_t ${host} "${app} stop || exit 1"
}

stop_titan_server(){

    local titan_server=/data/app/titan-servers/bin/titan-server
    local services_down=""
    local i=`expr ${#PACKAGE_TITAN_SERVER[*]} - 1`
    while [ $i -ge 0 ]
    do
        local ip=`get_ip ${PACKAGE_TITAN_SERVER[$i]}`
        if [ -z `echo ${services_down} |grep ${ip}` ]; then
            stop_erlang_node ${ip} ${titan_server}
            services_down="${services_down}**${ip}"
        fi
        let i--
    done
}

stop_titan_channel(){
    local ch_ip=`get_ip erl_channel_private`
    local channel=/data/app/titan-channel/bin/channel

    stop_erlang_node ${ch_ip} ${channel}

}

stop_titan_selector(){
    local sl_ip=`get_ip erl_selector_private`
    local selector=/data/app/titan-selector/bin/selector

    stop_erlang_node ${sl_ip} ${selector}
}

stop_titan_rabbitmq(){
    local mq_ip=`get_ip erl_rabbitmq`
    ssh_t ${mq_ip} "service rabbitmq-server stop || exit 1"
}

stop_erlang_services(){
    info_log "================= Stopping Selector =================="
    stop_titan_selector
    info_log "================= Stopping Server ===================="
    stop_titan_server
    info_log "================= Stopping Channel ==================="
    stop_titan_channel
    info_log "================= Stopping RabbitMQ =================="
    stop_titan_rabbitmq
}

start_titan_wisteria(){
    local java_ip=`get_ip java`
    ssh_t ${java_ip} "\
    nohup /etc/init.d/wisteria restart || exit 1; \
    echo \"==================== Check Server Status ===================\"; \
    for i in {1..30}; do \
    sleep 10; \
    echo -e \".\c\"; \
    ret=\`curl -Ss ${java_ip}:6100/v1/assets/selfcheck/checkall\`; \
    [ \$i -eq 30 ] && echo \"Java start check all timeout after 5 min. \$ret\" && exit 1; \
    [ -z \"\$ret\" ] && continue; \
    [ ! -z \"\$(echo \$ret|grep false)\" ] && echo \$ret; \
    [ -z \"\$(echo \$ret|grep false)\" ] && echo \$ret && exit 0; \
    done"
    check "Start java"
}

change_wisteria_memory(){
    local java_ip=`get_ip java`
    [ -z "${java_ip}" ] && error_log "java ip is empty"

    info_log "change java memory"
    read -p "change wisteria memory default [8192]:" MEM
    echo "$MEM"|[ -n "`sed -n '/^[0-9][0-9]*$/p'`" ] || MEM=8192
    ssh_t ${java_ip} "sed -i \"s/-Xmx.*M/-Xmx${MEM}M/\" /data/app/titan-wisteria/wisteria.conf"
    read -p "change gateway memory default [512]:" MEM
    echo "$MEM"|[ -n "`sed -n '/^[0-9][0-9]*$/p'`" ] || MEM=512
    ssh_t ${java_ip} "sed -i \"s/-Xmx.*M/-Xmx${MEM}M/\" /data/app/titan-gateway/gateway.conf"
    read -p "change user-srv memory default [1024]:" MEM
    echo "$MEM"|[ -n "`sed -n '/^[0-9][0-9]*$/p'`" ] || MEM=1024
    ssh_t ${java_ip} "sed -i \"s/-Xmx.*M/-Xmx${MEM}M/\" /data/app/titan-user-srv/user-srv.conf"
    read -p "change patrol-srv memory default [512]:" MEM
    echo "$MEM"|[ -n "`sed -n '/^[0-9][0-9]*$/p'`" ] || MEM=512
    ssh_t ${java_ip} "sed -i \"s/-Xmx.*M/-Xmx${MEM}M/\" /data/app/titan-patrol-srv/patrol-srv.conf"
}

stop_titan_wisteria(){
    local java_ip=`get_ip java`
    ssh_t ${java_ip} "/etc/init.d/wisteria stop || exit 1"
}

execute_config_py() {
    local version=$1
    local php_host=`get_ip php_inner_api`
    local config=/data/app/www/titan-web/config_scripts/config.py
    ssh_t ${php_host} "\
    echo \"Automatically run the second step: $config, finish all services configure.\"; \
    sed -i \"s#DEFAULT_SSH_PORT = 22#DEFAULT_SSH_PORT = $DEFAULT_PORT#\" $config; \
    /usr/bin/python $config -v ${version:="v2"} || exit 1"
    check "Config.py executed "
}

init_mysql_php(){
    local mysql_host=`get_ip db_mysql_php`
    local php_host=`get_ip php_inner_api`
    ssh_t ${php_host}  "\
    echo \"MySQL Inititaion....\"; \
    mysql --default-character-set=utf8 -h ${mysql_host} -uroot -p9pbsoq6hoNhhTzl < /data/app/www/titan-web/db/titan.sql; \
    mysql --default-character-set=utf8 -h ${mysql_host} -uroot -p9pbsoq6hoNhhTzl < /data/app/www/titan-web/db/titan-monitor.sql; \
    mysql --default-character-set=utf8 -h ${mysql_host} -uroot -p9pbsoq6hoNhhTzl < /data/app/www/titan-web/db/titan-user.sql; \
    mysql --default-character-set=utf8 -h ${mysql_host} -uroot -p9pbsoq6hoNhhTzl < /data/app/www/titan-web/db/titan-back.sql"
    check "init mysql "
}

start_php_worker(){
    local args_worker=install
    [ "$1" = "v3" ] && args_worker=install_v3
    local service_done=""
    for node in ${PACKAGE_TITAN_WEB[*]};
    do
        local ip=`get_ip ${node}`
        if [ -z "`echo ${service_done} |grep ${ip}`" ]; then
            ssh_t ${ip} "\
            [ -d /data/titan-logs/nginx ] || mkdir -p  /data/titan-logs/nginx && chown -R nginx:nginx /data/titan-logs/nginx;\
            chmod 755 -R /data/app && chown nginx:nginx -R /data/app/www; \
            /data/app/www/titan-web/script/update.sh && service nginx restart"
            check "build application.ini & Restart nginx "
            service_done="${service_done}@${ip}"
        fi
    done

    # worker running on php_inner_api site by defaults
    local worker_ip=`get_ip php_inner_api`
    ssh_t ${worker_ip} "\
    /data/app/www/titan-web/script/update.sh install && service nginx restart"
    check "Launching worker"
}


sync_rules(){
    local php_host=$1
    execute_rsync ${php_host} ${FILE_ROOT}/rules/ ${WEB_PATH}/rules
    ssh_t ${php_host}  "\
    echo \"================= 同步后台规则 =================\"; \
    [ -d ${WEB_PATH}/rules ] || (echo \"rules pack not found\" && exit 1); \
    [ -f ${WEB_PATH}/rules/titan-license-*.rpm ] && rm -f ${WEB_PATH}/rules/titan-license-*.rpm; \
    ${PHP_EXEC} ${WEB_PATH}/update/cli/pack.php -d ${WEB_PATH}/rules -f || exit 1"
}

update_agent_config(){

    local php_host=$1


    info_log "是否需要立刻更新agent [Y/N] ? default is Y"
    read -p "Enter [Y/N]: " Enter
    if [ "$Enter" != "n" ] && [ "$Enter" != "N" ];then


    ssh_t ${php_host}  "\
    echo \"============== 更新 Linux Agent 版本 ============\"; \
    ver_linux=\`ls /data/app/www/agent-update |grep '^v' |grep -v 'v*-win*'|sort -Vr |head -1\`; \
    [ -n \"\${ver_linux}\" ] && \
    ${PHP_EXEC} ${WEB_PATH}/script/update_agent.php \${ver_linux} && \
    echo linux agent version: \${ver_linux}; \
    [ \$? -ne 0 -a -n \"\${ver_linux}\" ] && echo failed && exit 1; \
    [ -z \"\${ver_linux}\" ] && echo [Warning]linux_agent_not_found; \

    echo \"============== 更新 Windows Agent 版本 ==========\"; \
    ver_win=\`ls /data/app/www/agent-update |grep '^v' |grep 'v*-win*' |sort -Vr |head -1\`; \
    [ -n \"\${ver_win}\" ] && sleep 12 && \
    ${PHP_EXEC} ${WEB_PATH}/script/update_win_agent.php \${ver_win} && \
    echo windows agent version: \${ver_win}; \
    [ \$? -ne 0 -a -n \"\$ver_win\" ] && echo failed && exit 1; \
    [ -z \"\${ver_win}\" ] && echo [Warning]windows_agent_not_found;"
    
    fi

    ssh_t ${php_host}  "\
    echo \"============== Touch titanagent.md5sum ========\"; \
    cd /data/app/www/agent-update && touch titanagent.md5sum && \
    chmod 655 titanagent.md5sum && echo titanagent.md5sum created || exit 1; \

    echo \"================= 配置bash安装 =================\"; \
    ${PHP_EXEC} ${WEB_PATH}/script/update_bash.php || exit 1; \

    service supervisord restart && supervisorctl status"

    local php_host_2=`get_ip php_download_private`
    ssh_t ${php_host_2}  "\
    echo \"============== Touch titanagent.md5sum ========\"; \
    cd /data/app/www/agent-update && touch titanagent.md5sum && \
    chmod 655 titanagent.md5sum && echo titanagent.md5sum created || exit 1"

}

init_data() {
    ## worker running on php_inner_api site by defaults
    local php_host=`get_ip php_inner_api`

    info_log "Execute: crontab ${WEB_PATH}/config_scripts/titan.cron"
    ssh_t ${php_host} "crontab ${WEB_PATH}/config_scripts/titan.cron && crontab -l"

    sync_rules ${php_host}

    update_agent_config ${php_host}

}

start_init_data() {
    info_log "Do you want to sync rules now [Y/N] ? default is Y"
    read -p "Enter [Y/N]: " Enter
    case $Enter in
        Y | y)
            init_data
            ;;
        N | n)
            exit 0
            ;;
        *)
            init_data
            ;;
     esac
}

check_backend_account() {
    local php_host=`get_ip php_inner_api`

    local register_back_v3_dir=${WEB_PATH}/user-backend/cli/

    local check_back_v3_script=check-back-register.php

    ssh_t ${php_host}  "\
    cd ${register_back_v3_dir} && \
    ${PHP_EXEC} ${check_back_v3_script}"

    check "Check backend account "
}

register_default_account() {
    ## php script executed on php_worker_site
    local php_host=`get_ip php_inner_api`

    local register_v2_dir=${WEB_PATH}/user-backend/cli/
    local register_back_v3_dir=${WEB_PATH}/user-backend/cli/
    local register_v3_dir=${WEB_PATH}/update/cli/

    local register_v2_script=back-default-register.php
    local register_back_v3_script=back-register.php
    local check_back_v3_script=check-back-register.php
    local register_v3_script=v3-tool-front-register.php

    local register_default_dir=${register_v3_dir}
    local register_default_script=${register_v3_script}

    [ "$1" = "v2" ] && register_default_dir=${register_v2_dir} && register_default_script=${register_v2_script}

    info_log "=================== 注册前台账号 ==================="
    read -ep "Input username (default: qingteng@qingteng.cn): " username
    read -ep "Input password:(default: qingteng@qt2018)" password

    echo ${username:="qingteng@qingteng.cn"}  ${password:="qingteng@qt2018"}

    ssh_t ${php_host}  "\
    cd ${register_default_dir} && \
    ${PHP_EXEC} ${register_default_script} ${username:=\"qingteng@qingteng.cn\"} ${password:=\"qingteng@qt2016\"};"

    check "Register console default account "

    info_log "是否需要自定义后台管理账户(默认与前台管理账户相同) [Y/N] ? default is N"
    read -p "Enter [Y/N]: " Enter
    if [ "$Enter" == "Y" ] || [ "$Enter" == "y" ];then
        info_log "=================== 注册后台账号 ==================="
        read -ep "Input username (default: qingteng@qingteng.cn): " username
        read -ep "Input password:(default: qingteng@qt2018)" password

        echo ${username:="qingteng@qingteng.cn"}  ${password:="qingteng@qt2018"}

        ssh_t ${php_host}  "\
        cd ${register_back_v3_dir} && \
        ${PHP_EXEC} ${register_back_v3_script} ${username:=\"qingteng@qingteng.cn\"} ${password:=\"qingteng@qt2018\"};"

        check "Register backend default account "
    fi
}


distribute(){

    local version=$1
    # erlang
    distribute_titan_server
    distribute_titan_channel
    distribute_titan_rabbitmq
    distribute_titan_selector

    #java
    [ "${version}" = "v3" ] && distribute_titan_wisteria

    #php
    distribute_titan_web
}

configuration(){
    local version=$1
    # upload ip_template.json to php server
    distribute_config
    # take effect
    execute_config_py ${version}
}

launch_services(){

    local version=$1

    start_php_worker ${version}
    start_erlang_services

    #java
    if [ "${version}" = "v3" ]; then
        change_wisteria_memory
        info_log "Restart java [Y/N] ? default is Y"
        read -p "Enter [Y/N]: " Enter
        [ -z "${Enter}" -o "${Enter}" = "Y" -o "${Enter}" = "y" ] && start_titan_wisteria
    fi

}

initialization(){
    local version=$1

    # sync rules
    start_init_data

    # register default account
    register_default_account ${version:="v2"}
}


install(){

    local version=$1

    info_log "================== RPM Installation =================="
    # distribution && install rpm
    distribute ${version:="v2"}

    info_log "================== Configuration ====================="
    configuration ${version:="v2"}
    # create databases
    init_mysql_php

    info_log "================== Launching Services ================"
    # launching services
    launch_services ${version:="v2"}

    info_log "================== Initialization ===================="
    # init data && sync rules
    initialization ${version:="v2"}
}

app_upgrade(){

    IS_UPGRADE=true

    local version=$1
    local ver_1=${version}
    local ver_2=${version}

    [ ${version} = "v2tov3" ] && ver_1="v2" && ver_2="v3"

    info_log "Stopping services [Y/N] ? default is Y"
    read -p "Enter [Y/N]: " Enter
    [ -z "${Enter}" -o "${Enter}" = "Y" -o "${Enter}" = "y" ] && setup_np_ssh_erlang && stop_erlang_services

    # basic lib config changed, then use upgrade-conf.sh to update config files
    info_log "upgrade config hotfix [Y/N] ? default is N"
    read -p "Enter [Y/N]: " Enter
    [ "${Enter}" = "Y" -o "${Enter}" = "y" ] && bash ${FILE_ROOT}/upgrade-conf.sh

    info_log "Distributing installation packages [Y/N] ? default is Y"
    read -p "Enter [Y/N]: " Enter
    [ -z "${Enter}" -o "${Enter}" = "Y" -o "${Enter}" = "y" ] && distribute ${ver_1}

    info_log "Distribute config files [Y/N] ? default is Y"
    read -p "Enter [Y/N]: " Enter
    [ -z "${Enter}" -o "${Enter}" = "Y" -o "${Enter}" = "y" ] && distribute_config && execute_config_py ${ver_2}

    info_log "Restart php [Y/N] ? default is Y"
    read -p "Enter [Y/N]: " Enter
    [ -z "${Enter}" -o "${Enter}" = "Y" -o "${Enter}" = "y" ] && start_php_worker ${ver_2}

    info_log "Restart erlang [Y/N] ? default is Y"
    read -p "Enter [Y/N]: " Enter
    [ -z "${Enter}" -o "${Enter}" = "Y" -o "${Enter}" = "y" ] && stop_erlang_services && start_erlang_services

}


# upgrade from 2.x to 2.x (include v3-lite)
upgrade_v2(){
    # application upgrade
    app_upgrade v2
    # rules update
    start_init_data
}

# upgrade from 3.x to 3.x
upgrade_v3(){
    info_log "Stopping Java Server [Y/N] ? default is Y"
    read -p "Enter [Y/N]: " Enter
    [ -z "${Enter}" -o "${Enter}" = "Y" -o "${Enter}" = "y" ] && stop_titan_wisteria

    app_upgrade v3

    info_log "Restart java [Y/N] ? default is Y"
    read -p "Enter [Y/N]: " Enter
    [ -z "${Enter}" -o "${Enter}" = "Y" -o "${Enter}" = "y" ] && start_titan_wisteria

    start_init_data
}


titan_mysql_dump(){
    local java_ip=`get_ip java`
    local mysql_ip=`get_ip db_mysql_php`
    ssh_t ${java_ip} "[ -f /data/app/titan-wisteria/config/java.json ] || (echo \"java.json not found\" && exit 1); \
    sed -i \"s/127.0.0.1/${mysql_ip}/g\" /data/app/titan-wisteria/config/java.json && \
    cd /data/app/titan-wisteria/v3-upgrade-script && \
    python2.7 upgrade.py backup"
}

titan_mysql_rollback(){
    local java_ip=`get_ip java`
    ssh_t ${java_ip} "cd /data/app/titan-wisteria/v3-upgrade-script && \
    python2.7 upgrade.py restore"
}

titan_db_merge(){
    local java_ip=`get_ip java`
    local comId=$1
    ssh_t ${java_ip} "cd /data/app/titan-wisteria/v3-upgrade-script && \
    python2.7 upgrade.py merge --main ${comId}"
}

java_db_flush(){
    local java_ip=`get_ip java`
    local comId=$1
    ssh_t ${java_ip} "cd /data/app/titan-wisteria/v3-upgrade-script && \
    python2.7 upgrade.py flushv3"
}

java_clean_cache(){
    local java_ip=`get_ip java`
    local comId=$1
    ssh_t ${java_ip} "cd /data/app/titan-wisteria/v3-upgrade-script && \
    python2.7 upgrade.py clearcache"
}

switch_company(){
    local java_ip=`get_ip java`
    local comId=$1
    local subId=$2
    ssh_t ${java_ip} "cd /data/app/titan-wisteria/v3-upgrade-script && \
    python2.7 upgrade.py switchcom --main ${comId} --sub ${subId}"
}


db_migrate(){

    info_log "Merging database [Y/N] ? default is Y"
    read -p "Enter [Y/N]: " Enter
    [ -z "${Enter}" -o "${Enter}" = "Y" -o "${Enter}" = "y" ] && \
    read -p "Input main comId: " Enter
    [ -z "${Enter}" ] && error_log "CompanyID is empty"
    [ ${#Enter} -eq 20 ] && java_db_flush && titan_db_merge ${Enter} || error_log "unexpected: ${Enter}"
}

customized_rules_migrate(){

    local php_host=`get_ip php_inner_api`

    info_log "Import customized baseline [Y/N]? default is N"
    read -p "Enter [Y/N]: " Enter
    [ "${Enter}" = "Y" -o "${Enter}" = "y" ] && \
    read -p "Input comId: " Enter && \
    ([ -z "${Enter}" ] && error_log "CompanyID is empty";

    [ ${#Enter} -eq 20 ] && ssh_t ${php_host} "\
    ${PHP_EXEC} ${WEB_PATH}/worker/tools/pa-baseline-rule-import-tool.php comid ${Enter};" || error_log "unexpected: ${Enter}")

    info_log "Import customized rules (webfile & shell-white)"
    ssh_t ${php_host}  "\
    cd ${WEB_PATH}/update/cli && ${PHP_EXEC} tool-webfile-sync.php;\
    cd ${WEB_PATH}/update/cli && ${PHP_EXEC} tool-import-shell-white.php"
}

upgrade_v2_to_v3(){

    info_log "Distribute Java application ? default is Y"
    read -p "Enter [Y/N]: " Enter
    [ -z "${Enter}" -o "${Enter}" = "Y" -o "${Enter}" = "y" ] && distribute_titan_wisteria

    info_log "Dumping database...."
    titan_mysql_dump

    # upgrade Erlang and PHP application
    app_upgrade v2tov3

    start_init_data

    # db from v2 to v3
    db_migrate

    info_log "Restart java [Y/N] ? default is Y"
    read -p "Enter [Y/N]: " Enter
    [ -z "${Enter}" -o "${Enter}" = "Y" -o "${Enter}" = "y" ] && start_titan_wisteria && java_clean_cache

    #info_log "Migrate customized rules"
    #customized_rules_migrate

}

## -------------------------- Start ------------------------------ ##

unzip_rules(){
    zipfile=`ls -t ${FILE_ROOT}/*-v*-*.zip | head -1`
    [ -z "${zipfile}" ] && exit 1

    [ -d ${FILE_ROOT}/rules ] && rm -rf ${FILE_ROOT}/rules
    mkdir -p ${FILE_ROOT}/rules
    unzip ${zipfile} -d ${FILE_ROOT}/rules
}

update_titan_license(){

    local licenses=(erl_om_1 erl_om_2 erl_dh_1 erl_dh_2 erl_sh_1_private erl_sh_2_private erl_channel_private erl_selector_private)
    local rpm_lic=`ls -t ${FILE_ROOT}/*/titan-license-*.rpm |head -1`
    local package_sent=""
    for node in ${licenses[*]};
    do
        local ip=`get_ip ${node}`
        if [ -z "`echo ${package_sent} |grep ${ip}`" ]; then
            execute_rsync ${ip} ${rpm_lic} ${REMOTE_QT_PACKAGE_DIR}
            install_rpm ${ip} ${rpm_lic##*/}
            package_sent="${package_sent}@${ip}"
        fi
    done

    info_log "Please restart (titan-channel, titan-server, titan-selector)"

}

while [ $# -gt 0 ]; do
    case $1 in
        distribute)
            # distribute packages & install rpm
            [ $# -ne 2 ] && echo "bash ./titan-app.sh distribute (v2 | v3)" && exit 1
            [ "$2" != "v2" -a "$2" != "v3" ] && echo "bash ./titan-app.sh distribute (v2 | v3)" && exit 1
            unzip_rules
            distribute $2
            exit 0
            ;;
        config)
            # scp ip_template.json to php server, execute config.py on php server
            [ $# -ne 2 ] && echo "bash ./titan-app.sh config (v2 | v3)" && exit 1
            [ "$2" != "v2" -a "$2" != "v3" ] && echo "bash ./titan-app.sh config (v2 | v3)" && exit 1
            configuration $2
            exit 0
            ;;
        init_db)
            # create databases & init data
            init_mysql_php
            exit 0
            ;;
        launch)
            # start application
            [ $# -ne 2 ] && echo "bash ./titan-app.sh launch (v2 | v3)" && exit 1
            [ "$2" != "v2" -a "$2" != "v3" ] && echo "bash ./titan-app.sh launch (v2 | v3)" && exit 1
            launch_services $2
            exit 0
            ;;
        init_data)
            # sync rules, agent, bash
            unzip_rules
            start_init_data
            exit 0
            ;;
        register)
            # register default account
            [ $# -ne 2 ] && echo "bash ./titan-app.sh register (v2 | v3)" && exit 1
            [ "$2" != "v2" -a "$2" != "v3" ] && echo "bash ./titan-app.sh install (v2 | v3)" && exit 1
            register_default_account $2
            exit 0
            ;;
        install)
            [ $# -ne 2 ] && echo "bash ./titan-app.sh install (v2 | v3)" && exit 1
            [ "$2" != "v2" -a "$2" != "v3" ] && echo "bash ./titan-app.sh install (v2 | v3)" && exit 1
            unzip_rules
            install $2
            check_backend_account
            exit 0
            ;;
        upgrade)
            [ $# -ne 2 ] && echo "bash ./titan-app.sh upgrade (v2 | v3)" && exit 1
            [ "$2" != "v2" -a "$2" != "v3" ] && echo "bash ./titan-app.sh upgrade (v2 | v3)" && exit 1
            unzip_rules
            [ "$2" = "v2" ] && upgrade_v2
            [ "$2" = "v3" ] && upgrade_v3 && check_backend_account
            exit 0
            ;;
        upgrade_v2_to_v3)
            unzip_rules
            upgrade_v2_to_v3
            check_backend_account
            exit 0
            ;;
        check_backend_account)
            check_backend_account
            exit 0
            ;;
        update_rules)
            # update rules
            unzip_rules
            php_host=`get_ip php_inner_api`
            sync_rules ${php_host}
            exit 0
            ;;
        update_agent_url)
            php_host=`get_ip php_inner_api`
            update_agent_config ${php_host}
            exit 0
            ;;
        update_license)
            unzip_rules
            update_titan_license
            exit 0
            ;;
        restart_php)
            [ $# -ne 2 ] && echo "bash ./titan-app.sh restart_php (v2 | v3)" && exit 1
            [ "$2" != "v2" -a "$2" != "v3" ] && echo "bash ./titan-app.sh restart_php (v2 | v3)" && exit 1
            start_php_worker $2
            exit 0
            ;;
        stop_erlang)
            setup_np_ssh_erlang
            #stop all erlang services (titan-server, channel, selector, rabbitmq)
            stop_erlang_services
            exit 0
            ;;
        start_erlang)
            setup_np_ssh_erlang
            # all erlang services
            start_erlang_services
            exit 0
            ;;
        start_server)
            # titan-server
            start_titan_server
            exit 0
            ;;
        stop_server)
            stop_titan_server
            exit 0
            ;;
        restart_om)
            # titan-server: om (distribution)
            start_server_role ${SERVER_EXEC} om_node
            exit 0
            ;;
        restart_dh)
            # titan-server: dh (distribution)
            start_server_role ${SERVER_EXEC} dh_node
            exit 0
            ;;
        restart_sh)
            # titan-server: sh l
            start_server_role ${SERVER_EXEC} sh_node
            exit 0
            ;;
        stop_java)
            stop_titan_wisteria
            exit 0
            ;;
        start_java)
            start_titan_wisteria
            exit 0
            ;;
        dump)
            titan_mysql_dump
            exit 0
            ;;
        rollback)
            titan_mysql_rollback
            exit 0
            ;;
        db_merge)
            # $2=comId
            java_db_flush
            titan_db_merge $2;
            exit 0
            ;;
        jdb_flush)
            java_db_flush
            exit 0
            ;;
        customized_rules)
            customized_rules_migrate
            exit 0
            ;;
        cleancache)
            java_clean_cache
            exit 0
            ;;
        upgrade_conf)
            bash ${FILE_ROOT}/upgrade-conf.sh
            exit 0
            ;;
        switchcompany)
            # $2=mainID, $3=subID
            switch_company $2 $3
            exit 0
            ;;
        change_wisteria_memory)
            change_wisteria_memory
            stop_titan_wisteria
            start_titan_wisteria
            exit 0
            ;;
         backup_config)
           backup_config
           exit 0
           ;;
         java_v310_update)
           java_v310_update $2
           exit 0
           ;;
        *)
            help $*
            exit 0
            ;;
    esac
done
exit 0
