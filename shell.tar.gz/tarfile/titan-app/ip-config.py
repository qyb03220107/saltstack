#!/usr/bin/env python2.7
# -*- coding: utf-8 -*-

"""
author: Shawn Xiong
date:  2017-11-02
email: xiaoxiao.xiong@qingteng.cn
"""

import json
import os
import sys
import getopt


def help():
    print "----------------------------------------------------------"
    print "                   Usage information"
    print "----------------------------------------------------------"
    print ""
    print "./ip-config.py [Args] "
    print "  -n --number=   the number of Servers                    "
    print "     ./ip-config.py -n 1                                  "
    print "     ./ip-config.py -n 4                                  "
    print "     ./ip-config.py -n 6                                  "
    print "----------------------------------------------------------"
    sys.exit(2)


__FILE_ABS_PATH = os.path.dirname(os.path.abspath(__file__))

__IP_TEMPLATE = "ip_template.json"

## One server
__DEFAULT_DOMAIN = "qingteng.cn"

## Erlang
__ERL_PRI_IP = ["erl_channel_private",
                "erl_rabbitmq",
                "erl_selector_private",
                "erl_om_1",
                "erl_om_2",
                "erl_dh_1",
                "erl_dh_2",
                "erl_sh_1_private",
                "erl_sh_2_private"]

__ERL_PUB_IP = ["erl_channel_public", "erl_selector_public", "erl_sh_1_public", "erl_sh_2_public"]

__ERL_DOMAIN = ["erl_channel_domain", "erl_selector_domain", "erl_sh_1_domain", "erl_sh_2_domain"]


## PHP
__PHP_PRI_IP = ["php_frontend_private",
                "php_backend_private",
                "php_agent_private",
                "php_download_private",
                "php_api_private",
                "php_inner_api",
                "php_worker_ip"]

__PHP_PUB_IP = ["php_frontend_public", "php_backend_public", "php_agent_public", "php_download_public", "php_api_public"]

__PHP_DOMAIN = ["php_frontend_domain",
                "php_backend_domain",
                "php_agent_domain",
                "php_download_domain",
                "php_api_domain",
                "php_inner_api_domain"]


try:
    __IP_CONF = json.load(file(__FILE_ABS_PATH + "/" + __IP_TEMPLATE))
except Exception as e:
    print "[WARN] ip_template.json not found, use backup file"
    use_backup_template()



def use_backup_template():
    """
    Using the backup ip_template.json when the default missing
    :return:
    """
    try:
        global __IP_CONF
        __IP_CONF = json.load(file(__FILE_ABS_PATH + "/.ip_template_bak.json"))

    except Exception as e:
        print str(e)
        exit(1)


def replace_ip(key, value):
    """
    Update IP address
    :param key: Erlang_(Pub|Pri) PHP_(Domain|Pub|Pri) MySQL_Server MongoDB_Redis | Java_Server | Java_DB
                or the key in ip_template.json
    :param value: IP address | domain
    :return:
    """
    try:
        if key == "erl_domain":
            for i in __ERL_DOMAIN:
                __IP_CONF[i] = value
        elif key == "erl_public":
            for i in __ERL_PUB_IP:
                __IP_CONF[i] = value
        elif key == "erl_private":
            for i in __ERL_PRI_IP:
                __IP_CONF[i] = value
        elif key == "php_domain":
            for i in __PHP_DOMAIN:
                if "php_frontend" in i and value != "":
                    __IP_CONF[i] = "console-sec." + value
                elif "php_backend" in i and value != "":
                    __IP_CONF[i] = "backend-sec." + value
                elif "php_agent" in i and value != "":
                    __IP_CONF[i] = "agent-sec." + value
                elif "php_download" in i and value != "":
                    __IP_CONF[i] = "download-sec." + value
                elif "php_api" in i and value != "":
                    __IP_CONF[i] = "api-sec." + value
                elif "php_inner_api" in i and value != "":
                    __IP_CONF[i] = "innerapi-sec." + value
        elif key == "php_public":
            for i in __PHP_PUB_IP:
                __IP_CONF[i] = value
        elif key == "php_private":
            for i in __PHP_PRI_IP:
                __IP_CONF[i] = value
        elif key == "MySQL_Server":
            __IP_CONF["db_mysql_erlang"] = value
            __IP_CONF["db_mysql_php"] = value
        elif key == "MongoDB_Redis":
            __IP_CONF["db_redis_erlang"] = value
            __IP_CONF["db_redis_php"] = value
        elif key == "Java_Server":
            __IP_CONF["java"] = value
            __IP_CONF["java_gateway"] = value
            __IP_CONF["java_patrol-srv"] = value
            __IP_CONF["java_user-srv"] = value
            __IP_CONF["java_kafka"] = value
            __IP_CONF["java_zookeeper"] = value
        elif key == "Java_DB":
            __IP_CONF["db_mongo_java"] = value
            __IP_CONF["db_redis_java"] = value
        else:
            __IP_CONF[key] = value
    except Exception as e:
        print str(e)
        exit(1)

def get_input(key, prompt="", default="127.0.0.1"):
    """
    Interacting with users, get ip address or domain from terminal
    :param key: key of dict
    :param prompt: hint
    :param default: default value
    :return: IP address
    """

    if prompt == "":
        prompt = "Input the ip of " + key + "(default {0}) : "

        if "domain" in key:
            prompt = "Input the " + key + "(default {0}) : "

    try:
        ip = raw_input(prompt.format(default)).strip()

        if ip == "":
            if default != "":
                return default
            elif "domain" not in key and "public" not in key:
                return "127.0.0.1"
        return ip
    except Exception as e:
        print str(e)
        exit(1)

def config_ip():
    """
    Traversing ip_template.json
    :return:
    """
    _ip_conf_key = sorted(__IP_CONF.keys())
    for key in _ip_conf_key:
        if key == "version":
            continue
        ip = get_input(key, "", __IP_CONF[key])
        replace_ip(key, ip)

def standalone_one():

    global __DEFAULT_DOMAIN

    domain = get_input("domain", "Input the domain ip of Server (default [*].{0}): ", "")
    ip_pub = get_input("public", "Input the public ip of Server (default {0}): ", "")
    ip_pri = get_input("private", "Input the private ip of Server (default {0}): ")

    _ip_conf_key = sorted(__IP_CONF.keys())
    for key in _ip_conf_key:
        if key == "version":
            continue
        if "domain" in key:
            if "php_frontend" in key and domain != "":
                replace_ip(key, domain)
            elif "php_backend" in key and domain != "":
                replace_ip(key, domain)
            elif "php_agent" in key and domain != "":
                replace_ip(key, domain)
            elif "php_download" in key and domain != "":
                replace_ip(key, domain)
            elif "php_api" in key and domain != "":
                replace_ip(key, domain)
            elif "php_inner_api" in key and domain != "":
                replace_ip(key, domain)
            elif __DEFAULT_DOMAIN == domain:
                # Using IP by default, but if the domain can be
                # resolved by DNS server that customer provided
                replace_ip(key, "")
                continue
            else:
                # channel & selector & erlang_sh
                replace_ip(key, domain)
        elif "public" in key:
            replace_ip(key, ip_pub)
        else:
            replace_ip(key, ip_pri)


def standalone_four():
    """
    Standard V2.0
    :return:
    """

    domain = get_input("erl_domain",
                       "Input the domain of Erlang Server (default {0}): ",
                       __IP_CONF["erl_selector_domain"])
    ip_pub = get_input("erl_public",
                       "Input the public ip of Erlang Server (default {0}): ",
                       __IP_CONF["erl_selector_public"])
    ip_pri = get_input("erl_private",
                       "Input the private ip of Erlang Server (default {0}): ",
                       __IP_CONF["erl_om_1"])

    replace_ip("erl_domain", domain)
    replace_ip("erl_public", ip_pub)
    replace_ip("erl_private", ip_pri)

    domain = get_input("php_domain",
                       "Input the domain of PHP Web Server (default [*].{0}): ",
                       __IP_CONF["php_frontend_domain"])
    ip_pub = get_input("php_public",
                       "Input the public ip of PHP Web Server (default {0}): ",
                       __IP_CONF["php_frontend_public"])
    ip_pri = get_input("php_private",
                       "Input the private ip of PHP Web Server (default {0}): ",
                       __IP_CONF["php_frontend_private"])

    replace_ip("php_domain", domain)
    replace_ip("php_public", ip_pub)
    replace_ip("php_private", ip_pri)

    ip = get_input("MySQL_Server", "", __IP_CONF["db_mysql_erlang"])
    replace_ip("MySQL_Server", ip)

    ip = get_input("MongoDB_Redis", "", __IP_CONF["db_redis_erlang"])
    replace_ip("MongoDB_Redis", ip)


def standalone_six():
    """
    Standard V3.0
    :return:
    """
    standalone_four()

    ip = get_input("Java_Server", "", __IP_CONF["java"])
    replace_ip("Java_Server", ip)

    ip = get_input("Java_MongoDB_Redis", "", __IP_CONF["db_mongo_java"])
    replace_ip("Java_DB", ip)


def save_user_input():
    """
    Update ip_template.json
    :return:
    """
    with open(__FILE_ABS_PATH + "/" + __IP_TEMPLATE, "w+") as f:
        f.write(json.dumps(__IP_CONF, indent = 4, sort_keys = True))


def main(argv):
    number = 0
    try:
        opts, args = getopt.getopt(argv, "n:", ["number="])
    except getopt.GetoptError:
        help()
    for opt, arg in opts:
        if opt in ("-n", "--number"):
            number = arg
        else:
            help()
            exit(1)

    if '1' == number:
        standalone_one()
    elif '4' == number:
        standalone_four()
    elif '6' == number:
        standalone_six()
    else:
        config_ip()

    print json.dumps(__IP_CONF, indent = 4, sort_keys = True)

    save_user_input()


if __name__ == '__main__':
    main(sys.argv[1:])
