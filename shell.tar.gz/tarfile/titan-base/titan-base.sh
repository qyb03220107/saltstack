#!/bin/bash
# ------------------------------------------------------------------------------
# @author:  jiang.wu
# @email:   jiang.wu@qingteng.cn
#-------------------------------------------------------------------------------

## ------------------------Marco Define--------------------------- ##

# error hint
COLOR_G="\x1b[0;32m"  # green
COLOR_R="\x1b[1;31m"  # red
RESET="\x1b[0m"
UPCONFIG=false

## ssh login
DEFAULT_PORT=22
DEFAULT_USER=root

ROOT=`cd \`dirname $0\` && pwd`
## Local
QT_DEPS_ROOT=${ROOT}

## config file: server_name  ip
ROLE_IP_TEMPLATE=${ROOT}/.role_template
SERVER_IP_CONF=${ROOT}/service_ip.conf

## The dir that need to be sent to remote server
QT_ERLANG_DEPS=("${QT_DEPS_ROOT}/base")
QT_JAVA_DEPS=("${QT_DEPS_ROOT}/base" "${QT_DEPS_ROOT}/java")
QT_PHP_DEPS=("${QT_DEPS_ROOT}/base" "${QT_DEPS_ROOT}/php")
QT_MYSQL_DEPS=("${QT_DEPS_ROOT}/base" "${QT_DEPS_ROOT}/mysql")
QT_REDIS_DEPS=("${QT_DEPS_ROOT}/base" "${QT_DEPS_ROOT}/redis")
QT_MONGO_DEPS=("${QT_DEPS_ROOT}/base" "${QT_DEPS_ROOT}/mongo")


## Remote
## The remote dir that receive related deps
REMOTE_SERVER_DIR=("/data/qt_base")


## -----------------------Utils Functions------------------------- ##
help() {
    echo "-------------------------------------------------------------------------------"
    echo "                        Usage information"
    echo "-------------------------------------------------------------------------------"
    echo ""
    echo "./titan-base.sh [<all | erlang | php | java | mysql | redis| mongo>] [upconfig]"
    echo "Options:"
    echo "  all           set up environments for all server                             "
    echo "  erlang        set up environments for erlang server                          "
    echo "  php           set up environments for php server                             "
    echo "  java          set up environments for java server                            "
    echo "  mysql         set up environments for mysql server(master&slave)             "
    echo "  redis_php     set up environments for redis server                           "
    echo "  redis_java    set up environments for redis server                           "
    echo "  redis_erlang  set up environments for redis server                           "
    echo "  mongo_java    set up environments for mongo server                           "
    echo "  mongo_erlang  set up environments for mongo server                           "
    echo "  pre_check     check ports before installation                                "
    echo "  ping_server   check the connectivity of QT servers                           "
    echo "  stop_python   stop dummy python server                                       "
    echo "  after_check   check ports after installation finished                        "
    echo "  titan_manager_server   manager all server                                    "
    echo ""
    echo "  One-key install:"
    echo "    ./titan-base.sh all"
    echo "  Install for specific server:"
    echo "    ./titan-base.sh erlang"
    echo "-------------------------------------------------------------------"
    exit 1
}

info_log(){
    echo -e "${COLOR_G}[Info] ${1}${RESET}"
}

error_log(){
    echo -e "${COLOR_R}[Error] ${1}${RESET}"
}

check(){
    if [ $? -eq 0 ];then
        info_log "$* Successfully"
    else
        error_log "$* Failed"
        exit 1
    fi
}

is_dir_existed(){
    local dirs=$*
    for d in ${dirs}
    do
        if [ ! -d ${d} ]
        then
            error_log "Dir not exists: ${QT_DEPS_ROOT}/${d}"
            exit 1
        fi
    done
}

ssh_t(){
    ssh -t -p ${DEFAULT_PORT} -oStrictHostKeyChecking=no ${DEFAULT_USER}@$1 $2
}
ssh_tt(){
    ssh -tt -p ${DEFAULT_PORT} -oStrictHostKeyChecking=no ${DEFAULT_USER}@$1 $2
}

set_np_authorized(){
    local ip=$1
    ${ROOT}/scripts/setup_np_ssh.sh ${DEFAULT_USER}@${ip} ${DEFAULT_PORT}
}

execute_rsync(){
    local host=$1
    local pkg=$2
    local remote_dir=$3

    rsync -rz -e "ssh -p $DEFAULT_PORT"  --delete ${pkg} root@${host}:${remote_dir}/
    check "rsync ${pkg} to ${host} "
}

ensure_remote_dir_exists(){
    local host=$1
    local cmd="cd ${REMOTE_SERVER_DIR} 2> /dev/null"
    ssh root@${host} ${cmd}
    if [ $? -ne 0 ]; then
        info_log "Creating ${REMOTE_SERVER_DIR}!"
        ssh_t ${host} "mkdir -p ${REMOTE_SERVER_DIR}"
        check "${REMOTE_SERVER_DIR} created on ${host}."
    fi
}

clean_yum_complete_transaction(){
    local host=$1
    ssh_t ${host} "! which yum-complete-transaction || yum-complete-transaction --cleanup-only"
}

get_role_host(){
    local role=$1
    if [ ! -f ${SERVER_IP_CONF} ]; then
        error_log "Not found service_ip.conf file."
        exit 1
    fi
    cat ${SERVER_IP_CONF}|grep $role|awk -F" " '{print $2}'|head -1
}


## -----------------------Install--------------------------------- ##
install_rpm(){
    local host=$1
    local rpms=$2

    info_log "Install ${rpms}...."

    # comment the next line when offline
    local cmd="yum -y --skip-broken localinstall ${rpms} >> /root/qingteng.log"

    # uncomment the next line when offline
    # local cmd="yum -y --skip-broken --disablerepo=* localinstall ${rpms} >> /root/qingteng.log"

    ssh_t ${host} ${cmd}

    check "Install ${rpms}"
}

execute_remote_shell(){
    local host=$1
    local name=$2
    local args=$2

    case ${name} in
        redis_erlang|redis_php|redis_java)
            name=redis
            ;;
        mongo_erlang|mongo_java|enable_auth)
            name=mongo
            ;;
        mysql|mysql_erlang|mysql_php|mysql_master|mysql_slave)
            name=mysql
            ;;
        erlang|php)
            if [ "$name" == "php" ];then
                local java_ip=`get_role_host java`
                args="${java_ip}"
            fi
            ;;
        java)
            # pass zookeeper'ip to kafka
            local zk_ip=`get_role_host zookeeper`
            args="${args} ${zk_ip}"
            ;;
        *)
            exit 1
            ;;
    esac

    info_log "======== Execute shell on remote server $host($2) ========"
    if [ "$UPCONFIG" == "true" ];then
        ssh_t ${host} "[ ! -f ${REMOTE_SERVER_DIR}/${name}/install_${name}.sh ] \
        || bash ${REMOTE_SERVER_DIR}/${name}/install_${name}.sh upconfig ${args}"
        check "upconfig ${name}"
        check "execute shell on $host($2)"
    else
        ssh_t ${host} "[ ! -f ${REMOTE_SERVER_DIR}/${name}/install_${name}.sh ] \
        || bash ${REMOTE_SERVER_DIR}/${name}/install_${name}.sh ${args}"
        check "Install ${name}"
        check "execute shell on $host($2)"
    fi

}

install_erlang(){
    local host=$1
    clean_yum_complete_transaction ${host}

    execute_remote_shell ${host} erlang
}

install_php(){
    local host=$1
    clean_yum_complete_transaction ${host}


    execute_remote_shell ${host} php
}

install_java(){
    local host=$1
    clean_yum_complete_transaction ${host}


    execute_remote_shell ${host} java
}

install_mysql(){
    local host=$1
    local role=$2 # mysql | mysql_php | mysql_erlang
    clean_yum_complete_transaction ${host}


    execute_remote_shell ${host} ${role}
}

install_redis(){
    local host=$1
    local role=$2 # redis_erlang | redis_php | redis_java
    clean_yum_complete_transaction ${host}

    execute_remote_shell ${host} ${role}
}

install_mongo(){
    local host=$1
    local role=$2 # mongo_erlang | mongo_java
    clean_yum_complete_transaction ${host}


    execute_remote_shell ${host} ${role}
}

install_by_role(){
    local name=$1
    local ip=$2

    if [[ -z ${ip} || ${ip} = "127.0.0.1" ]]; then
        error_log "Invalid IP ${ip} for ${name} server"
        return
    fi

    case ${name} in
        erlang)
            install_erlang ${ip}
            ;;
        php)
            install_php ${ip}
            ;;
        java)
            install_java ${ip}
            ;;
        mysql|mysql_php|mysql_erlang|mysql_master|mysql_slave)
            install_mysql ${ip} ${name}
            ;;
        redis_java|redis_erlang|redis_php)
            install_redis ${ip} ${name}
            ;;
        mongo_java|mongo_erlang)
            install_mongo ${ip} ${name}
            ;;
        zookeeper|kafka)
            # Ignore currently, Zookeeper & Kafka were built-in role java
            ;;
          *)
            help
            ;;
    esac

}


upconfig_by_role(){
    local name=$1
    local ip=$2

    if [[ -z ${ip} || ${ip} = "127.0.0.1" ]]; then
        error_log "Invalid IP ${ip} for ${name} server"
        return
    fi

    execute_remote_shell ${ip} ${name}

}

## -----------------------Distribution---------------------------- ##
distribute_packets(){
    local dir=$1
    local host=$2

    info_log "Sending: ${dir[@]} to ${host}"

    execute_rsync ${host} "${dir}" "${REMOTE_SERVER_DIR}"
#    rsync -rz --delete ${dir} root@${host}:${REMOTE_SERVER_DIR}/
}

distribute_by_role(){
    local name=$1
    local ip=$2

    set_np_authorized ${ip}

    if [[ -z ${ip} || ${ip} = "127.0.0.1" ]]; then
        return
    fi

    case ${name} in
        erlang)
            is_dir_existed ${QT_ERLANG_DEPS[*]}
            ensure_remote_dir_exists ${ip}
            info_log "Sending package to Erlang Server"
            distribute_packets "${QT_ERLANG_DEPS[*]}" ${ip}
            ;;
        php)
            is_dir_existed ${QT_PHP_DEPS[*]}
            ensure_remote_dir_exists ${ip}
            info_log "Sending package to PHP Server"
            distribute_packets "${QT_PHP_DEPS[*]}" ${ip}
            ;;
        java)
            is_dir_existed ${QT_JAVA_DEPS[*]}
            ensure_remote_dir_exists ${ip}
            info_log "Sending package to Java Server"
            distribute_packets "${QT_JAVA_DEPS[*]}" ${ip}
            ;;
        mysql|mysql_php|mysql_erlang|mysql_master|mysql_slave)
            is_dir_existed ${QT_MYSQL_DEPS[*]}
            ensure_remote_dir_exists ${ip}
            info_log "Sending package to MySQL Server"
            distribute_packets "${QT_MYSQL_DEPS[*]}" ${ip}
            ;;
        redis_java|redis_erlang|redis_php)
            is_dir_existed ${QT_REDIS_DEPS[*]}
            ensure_remote_dir_exists ${ip}
            info_log "Sending package to Redis Server"
            distribute_packets "${QT_REDIS_DEPS[*]}" ${ip}
            ;;
        mongo_java|mongo_erlang)
            is_dir_existed ${QT_MONGO_DEPS[*]}
            ensure_remote_dir_exists ${ip}
            info_log "Sending package to MongoDB Server"
            distribute_packets "${QT_MONGO_DEPS[*]}" ${ip}
            ;;
        zookeeper|kafka)
            # Ignore currently, Zookeeper & Kafka were built-in role java
            ;;
          *)
            help
            ;;
    esac
}

enable_mongo_auth(){
    local ips=$*
    for ip in ${ips[*]}; do
        info_log "================ Enable MongoDB Auth ($ip) ================"
        execute_remote_shell ${ip} enable_auth
    done
}

check_hostname(){
    local ip=$1
    info_log "Check hostname"
    ssh_t ${ip} "tag=\`hostname\`; [ -z \"\`grep 127.0.0.1 /etc/hosts|grep \$tag\`\" ] && echo \"127.0.0.1 \$tag\" >> /etc/hosts"
}

check_path(){
    local ip=$1
    local usrbin="/usr/local/bin"
    info_log "Check PATH"
    ssh_t ${ip} "[ -z \"\`echo \$PATH|grep ${usrbin}\`\" ] && echo \"export PATH=${usrbin}:\\\$PATH\" >> /etc/profile && source /etc/profile"
}

start(){
    if [ -f ${SERVER_IP_CONF} ]; then
        # distribute or install
        local flag=$1
        # default: all components
        local content=`cat ${SERVER_IP_CONF}`
        # specific components according to $1
        if [ $2 != all ]; then
            # start with $2
            content=`cat ${SERVER_IP_CONF} |grep ^$2`
        fi

        (IFS=$'\n';for line in ${content}; do
         local name=`echo ${line} | awk -F " " '{print $1}'`
         local host=`echo ${line} | awk -F" " '{print $2}'`
            if [ "${flag}" == "distribute" ]; then
                check_hostname ${host}
                check_path ${host}
                # send packages
                distribute_by_role ${name} ${host}
            elif [ "${flag}" == "install" ]; then
                 install_by_role ${name} ${host}
                # store mongodb ip, to enable auth after mongodb initiation
                if [ ! -z `echo ${name} |grep ^mongo` ]; then
                    echo "${host}" >> ${ROOT}/mongo_ips.tmp
                fi
            elif [ "${flag}" == "upconfig" ]; then
                upconfig_by_role ${name} ${host}
            fi
         done;)

         # enable mongo auth
        if [ -f ${ROOT}/mongo_ips.tmp ]; then
            local mongo_ips=`cat ${ROOT}/mongo_ips.tmp |sort |uniq`
            rm -f ${ROOT}/mongo_ips.tmp
            enable_mongo_auth ${mongo_ips}
        fi

    fi
}

mysql_master_slave(){

    local slave_ip=`grep mysql_slave ${SERVER_IP_CONF}| awk -F " " '{print $2}'`

    [ -z "${slave_ip}" ] && exit 0

    local master_ip=`grep mysql_master ${SERVER_IP_CONF}| awk -F " " '{print $2}'`

    info_log "========== Show MySQL master status ==========="
    ssh_t ${master_ip} "\
    ret=\"\`mysql -uroot -p9pbsoq6hoNhhTzl -e \"show master status\"\`\"; \
    echo \${ret}" > /tmp/qingteng-mysql-master-status
    result="`cat /tmp/qingteng-mysql-master-status`"
    local bin_file=`echo ${result}| awk -F " " '{print $5}'`
    local file_pos=`echo ${result}| awk -F " " '{print $6}'`

    [ -z "${bin_file}" ] && echo "Cannot found mysql file: mysql-bin.*" && exit 1
    [ -z "${file_pos}" ] && echo "Cannot found file position" && exit 1

    echo "File: ${bin_file}"
    echo "Position: ${file_pos}"

    info_log "========== Connect to Master Server ==========="

    info_log "Stop slave..."
    ssh_t ${slave_ip} "mysql -uroot -p9pbsoq6hoNhhTzl -e \"stop slave;\""

    sleep 1
    info_log "Change master to..."
    ssh_t ${slave_ip} "mysql -uroot -p9pbsoq6hoNhhTzl -e \"\
    change master to master_host=\\\"${master_ip}\\\", master_user=\\\"root\\\", master_password=\\\"9pbsoq6hoNhhTzl\\\", master_log_file=\\\"${bin_file}\\\", master_log_pos=${file_pos};
    start slave;\""

    sleep 2
    info_log "Show slave status"
    ssh_t ${slave_ip} "mysql -uroot -p9pbsoq6hoNhhTzl -e \"show slave status\\\G;\""
}


main(){
    local name=$1
    echo "--------------------Packet Distribution--------------------"
    start distribute ${name}

    if [ $? -ne 0 ]; then
        exit 1
    fi

    echo "--------------------RPM Packets Install--------------------"
    info_log "Start installing dependency lib"
    if [ "$UPCONFIG" == "true" ];then
        start upconfig ${name}
    else
        start install ${name}
        mysql_master_slave
    fi

}


manager_server(){
    if [[ -z $1 || $1 = "127.0.0.1" ]]; then
        return
    else
        info_log "Execute shell on remote server $1 $2 $3"
        ssh_t $1 "service $3 $2"
    fi
}

titan_manager_server(){
    if [ $# -ne 2 ];then 
        help $*
    else
      [ $2 != "start" ] &&  [ $2 != "stop" ] && [ $2 != "restart" ] &&  [ $2 != "status" ] && help $*
    fi
    
    if [ "$1" == "mysql" ] || [ "$1" == "all" ];then
        local mysql_ip=`get_role_host mysql`
        manager_server $mysql_ip $2 mysqld
    fi
    if [ "$1" == "redis_php" ] || [ "$1" == "all" ];then
        local redis_php_ip=`get_role_host redis_php`
        manager_server $redis_php_ip $2 redis6380d
    fi
    if [ "$1" == "redis_erlang" ] || [ "$1" == "all" ];then
        local redis_erlang_ip=`get_role_host redis_erlang`
        manager_server $redis_erlang_ip $2 redis6379d
    fi
    if [ "$1" == "redis_java" ] || [ "$1" == "all" ];then
        local redis_java_ip=`get_role_host redis_java`
        manager_server $redis_java_ip $2 redis6381d
    fi
    if [ "$1" == "mongo_java" ] || [ "$1" == "all" ];then
        local mongo_java_ip=`get_role_host mongo_java`
        manager_server $mongo_java_ip $2 mongod
    fi
    if [ "$1" == "zookeeper" ] || [ "$1" == "all" ];then
        local zookeeper_ip=`get_role_host zookeeper`
        manager_server $zookeeper_ip $2 zookeeperd
    fi
    if [ "$1" == "kafka" ] || [ "$1" == "all" ];then
        local kafka_ip=`get_role_host kafka`
        manager_server $kafka_ip $2 kafkad
    fi
    if [ "$1" == "java" ] || [ "$1" == "all" ];then
        local java_ip=`get_role_host java`
        manager_server $java_ip $2 wisteria
    fi
    if [ "$1" == "erlang" ] || [ "$1" == "all" ];then
        local erlang_ip=`get_role_host erlang`
        manager_server $erlang_ip $2 selector
        manager_server $erlang_ip $2 channel
        manager_server $erlang_ip $2 titan-servers
    fi
    if [ "$1" == "php" ] || [ "$1" == "all" ];then
        local php_ip=`get_role_host php`
        manager_server $php_ip $2 php-fpm
        manager_server $php_ip $2 supervisord 
        manager_server $php_ip $2 nginx
    fi
}

## ----------------------------Starting--------------------------- ##

[ $# -gt 0 ] || help $*

start_arg=$1
[ "$2" == "upconfig" ] && UPCONFIG=true

while [ $# -gt 0 ]; do
    case $1 in
        all)
            main all
            exit 0
            ;;
        erlang)
            main erlang
            exit 0
            ;;
        php)
            main php
            exit 0
            ;;
        java)
            main java
            exit 0
            ;;
        mysql)
            main mysql
            mysql_master_slave
            exit 0
            ;;
        redis)
            main redis
            exit 0
            ;;
        redis_erlang)
            main redis_erlang
            exit 0
            ;;
        redis_php)
            main redis_php
            exit 0
            ;;
        redis_java)
            main redis_java
            exit 0
            ;;
        mongo)
            main mongo
            exit 0
            ;;
        mongo_erlang)
            main mongo_erlang
            exit 0
            ;;
        mongo_java)
            main mongo_java
            exit 0
            ;;
        pre_check)
            ${ROOT}/scripts/portscan.sh start
            exit 0
            ;;
        ping_server)
            ${ROOT}/scripts/portscan.sh ping
            exit 0
            ;;
        stop_python)
            ${ROOT}/scripts/portscan.sh stop
            exit 0
            ;;
        after_check)
            ${ROOT}/scripts/portscan.sh qt_ports
            exit 0
            ;;
        titan_manager_server)
            titan_manager_server $2 $3
            exit 0
            ;;
        *)
            help $*
            exit 0
            ;;
    esac
done
exit 0
