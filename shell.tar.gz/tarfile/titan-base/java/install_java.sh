#!/bin/bash

## --------------------Marco Define------------------------------- ##
# error hint
COLOR_G="\x1b[0;32m"  # green
COLOR_R="\x1b[1;31m"  # red
RESET="\x1b[0m"

## sys
QT_PACKAGE_ROOT="/data/qt_base"
QT_SYS_CONF="${QT_PACKAGE_ROOT}/base/config"

## java
QT_PACKAGE_DIR="/data/qt_base/java"
QT_CONF="${QT_PACKAGE_DIR}/config"

## installation directory
QT_INSTALL_DIR=/usr/local/qingteng

QT_ZK_DIR=zookeeper
QT_ZK_DATA=/data/zk-data

QT_KAFKA_DIR=kafka
QT_KAFKA_LOG=/data/kafka-logs
QT_KAFKA_PARTITIONS_NUM=3

## --------------------Utils-------------------------------------- ##

info_log(){
    echo -e "${COLOR_G}[Info] ${1}${RESET}"
}

error_log(){
    echo -e "${COLOR_R}[Error] ${1}${RESET}"
}

check(){
    if [ $? -eq 0 ];then
        info_log "$1 Successfully"
    else
        error_log "$1 Failed"
        exit 1
    fi
}

remove_dir(){
    local dir=$1
    if [ -e ${dir} ]; then
        rm -rf ${dir}
        info_log "remove dir ${dir}"
    fi
}

## --------------------Tar Packets Install------------------------ ##

install_python(){
    python2.7 -V
    if [ $? -ne 0 ]; then
        info_log "Install Python2.7...."
        mysqldump --version || yum -y install qingteng-percona
        yum -y install  qingteng-python
        check "Install Python2.7"
    else
        python_path=`which python2.7`
        if [ "$python_path" != "/usr/local/sbin/python2.7" ] || [ "$python_path" != "/usr/local/bin/python2.7" ];then
            #python_dir=`dirname $python_path`
            #mv $python_path $python_dir/python27
            
            info_log "Install Python2.7...."
            mysqldump --version || yum -y install qingteng-percona
            yum -y install  qingteng-python
            check "Install Python2.7"
        fi
    fi
}

install_zk(){

    if [ ! -f ${QT_INSTALL_DIR}/${QT_ZK_DIR}/conf/zoo.cfg ]; then
        remove_dir ${QT_INSTALL_DIR}/${QT_ZK_DIR}
        yum -y install qingteng-zookeeper
        update_config "${QT_CONF}/zoo.cfg" /usr/local/qingteng/zookeeper/conf/
        check "Install zookeeper"
    else
        info_log "zookeeper already exits: ${QT_INSTALL_DIR}/${QT_ZK_DIR}"
    fi
}

install_kafka(){
    if [ ! -e ${QT_INSTALL_DIR}/${QT_KAFKA_DIR}/bin ]; then
        remove_dir ${QT_INSTALL_DIR}/${QT_KAFKA_DIR}
        yum -y install qingteng-kafka
        update_config "${QT_CONF}/server.properties" /usr/local/qingteng/kafka/config/
        check "Install kafka"
    else
        info_log "kafka already exits: ${QT_INSTALL_DIR}/${QT_KAFKA_DIR}"
    fi
}

## -------------------------Configure------------------------------ ##

update_config(){
    local qt_conf=$1
    local dest_dir=$2

    [ -f ${qt_conf} ] || exit 1

    if [ ! -z ${dest_dir} ]
    then
        cp -b ${qt_conf} ${dest_dir}
        check "Copy ${qt_conf} to ${dest_dir}"
    fi
}

config_conf(){
    local conf_path=$1
    local conf=${conf_path}/conf.conf

    if [ -f ${conf} ]; then
        (IFS=$'\n';for line in `cat $conf`; do
             local file=`echo ${line} | awk -F " " '{print $1}'`
             local dest=`echo ${line} | awk -F" " '{print $2}'`
             update_config "${conf_path}/${file}" ${dest}
        done)
    fi
}

## -------------------------Launch Services----------------------- ##

init_sys(){
    # sys config
    config_conf ${QT_SYS_CONF}
    sed -i '/^*/d' /etc/security/limits.d/*.conf
    modprobe bridge && sysctl -p
    sysctl -a > /root/qingteng_sysctl.log
    if [ `command -v abrtd` ]; then
        [ -f /etc/abrt/abrt-action-save-package-data.conf ] && \
        sed -i 's/ProcessUnpackaged = no/ProcessUnpackaged = yes/' /etc/abrt/abrt-action-save-package-data.conf
        service abrtd restart
    fi
    check "Load sys config"
}

add_service_zk(){
    if [ -f /etc/init.d/zookeeperd ]; then
        chmod +x /etc/init.d/zookeeperd
        chkconfig --add zookeeperd
        chkconfig zookeeperd on
    fi
}

add_service_kafka(){
    if [ -f /etc/init.d/kafkad ]; then
        chmod +x /etc/init.d/kafkad
        chkconfig --add kafkad
        chkconfig kafkad on
    fi
}

check_hostname(){
    info_log "check hostname"
    local hostname=`hostname`
    [ -z `grep 127.0.0.1 /etc/hosts|grep ${hostname}` ] && \
    echo -e "127.0.0.1  ${hostname}" >> /etc/hosts
    cat /etc/hosts
}

all_java(){
    # python2.7 
    install_python 

    # zookeeper & kafka
    check_hostname
    install_zk
    install_kafka

    # sys config
    init_sys

    # app config
    # config_conf ${QT_CONF}

    # add services
    add_service_zk
    add_service_kafka

    # launch services
    service kafkad stop
    info_log "launching zookeeper"
    service zookeeperd restart
    sleep 5
    info_log "launching kafka"
    service kafkad restart >/dev/null
    sleep 3
    service kafkad restart 
}

## -------------------------Starting------------------------------ ##
if [ "$1" == "upconfig" ];then
    config_conf ${QT_CONF}
    service zookeeperd restart
    service kafkad restart
    exit 0
fi


if [ ! -z $2 ]; then
    QT_ZK_IP=$2
else
    error_log "zookeeper's IP is empty"
    exit 1
fi


if [ ! -f "/etc/yum.repos.d/qingteng.repo" ];then
    if [ ! -d "/etc/yum.repos.d/qingteng-bak" ];then
        mkdir /etc/yum.repos.d/qingteng-bak
        mv /etc/yum.repos.d/*.repo  /etc/yum.repos.d/qingteng-bak
    fi
cat >/etc/yum.repos.d/qingteng.repo<<EOF
[qingteng]
name=qingteng
baseurl=file://${QT_PACKAGE_ROOT}/base/qingteng
enabled=1
gpgcheck=0
EOF
yum clean all
fi


case $1 in
    java)
        all_java
        ;;
    zookeeper)
        install_zk
        add_service_zk
        service zookeeperd restart
        ;;
    kafka)
        install_kafka
        add_service_kafka
        service kafkad restart
        ;;
    *)
        echo "Usage: {java|zookeeper|kafka}"
        exit 1
        ;;
esac

info_log "Done"
